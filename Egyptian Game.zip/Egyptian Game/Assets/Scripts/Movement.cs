﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour
{
    public float speed = 1.5f;
    public Sprite idle;
    public Camera c;
    public AudioSource sand;
    private bool walk;
    

    void Update()
    {
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.position += Vector3.left * speed * Time.deltaTime;
            sand.PlayDelayed(1);
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.position += Vector3.right * speed * Time.deltaTime;
            walk = true;
        }
        else if (Input.GetKey(KeyCode.UpArrow))
        {
            transform.position += Vector3.up * speed * Time.deltaTime;
            walk = true;
        }
        else if (Input.GetKey(KeyCode.DownArrow))
        {
            transform.position += Vector3.down * speed * Time.deltaTime;
            walk = true;
        }
        else
        {
            
            this.gameObject.GetComponent<SpriteRenderer>().sprite = idle;
            walk = false;
        }


    }
    IEnumerator playSoundAfterTenSeconds()
    {
        yield return new WaitForSeconds(1);
        sand.Play();
    }

    // then elsewhere when you want to invoke it:

    void someOtherMethodInAMonoBehaviour()
    {
        StartCoroutine(playSoundAfterTenSeconds());
    }
}